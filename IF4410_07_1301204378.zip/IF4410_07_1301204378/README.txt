===============================================================================
===                     KELOMPOK 7 || IF-44-10                              ===
===             Berlian Muhammad Galin Al Awienoor (1301204378)             ===
===             Kiki Dwi Prasetyo                  (1301204027)             ===
===============================================================================

Terdapat penjelasan setiap fungsi/prosedur.
Pada awal program diinputkan file bengkel.xlsx dan pada akhir program dioutputkan file peringkat.xlsx.
Setiap kode program yang bertujuan menampilkan grafik, grafik akan muncul dibawahnya (menggunakan google collab).
Untuk video presentasi kita upload di google drive, link nya dibawah ini:
https://drive.google.com/file/d/12o_jI6QuBI-pq7XHbm2Tc81Qso8m4PDE/view?usp=sharing

================================= TERIMAKASIH =================================